package com.cg.dao;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.*;
import com.cg.exception.*;
import com.cg.util.DBUtil;


public class AdminDaoImpl implements AdminDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	PreparedStatement pst2=null;
	ResultSet rs=null;
	ResultSet rs2=null;
	Logger admLogger=null;
	
	public AdminDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		admLogger = Logger.getLogger("AdminDaoImpl.class");
	}
	
	@Override
	public int addHotels(Hotels htl) throws HotelException
	{

		int dataAdded=0;	
		try
		{
			con =DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.INSERT_HOTEL);

			pst.setString(1,generateHotelId());
			pst.setString(2,htl.getCity());
			pst.setString(3,htl.getHotelName());
			pst.setString(4,htl.getAddress());
			pst.setString(5,htl.getDescription());
			pst.setFloat(6,htl.getAvgRate());
			pst.setString(7,htl.getPh1());
			pst.setString(8,htl.getPh2());
			pst.setString(9,htl.getRating());
			pst.setString(10,htl.getEmail());
			pst.setString(11,htl.getFax());
			dataAdded=pst.executeUpdate();
			admLogger.log(Level.INFO,"Data Inserted: "+htl);
		}
		catch(Exception e)
		{	
			admLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
				st.close();
			}
			catch(SQLException e)
			{
				admLogger.error("This is Exception:"+e.getMessage());
				throw new HotelException(e.getMessage());
			}
		}
		return dataAdded;	
	}

	 @Override
	    public int updateHtl(Hotels hotel) throws HotelException 
	    {

	        try
	        {
	            con=DBUtil.getCon();
	            pst = con.prepareStatement("SELECT * from hotel where hotel_id=?");
	            //System.out.println("Id...." + hotel.getHotelId());
	            pst.setString(1, hotel.getHotelId());
	            rs=pst.executeQuery();

	            //String city = rs.getString("city");
	            if( rs.next() ){
	                //String city1 = rs.getString("city");
	                //System.out.println("city inside upate..." + city1);
	                pst=con.prepareStatement(QueryMapper.UPDATE_HOTEL);
	                //System.out.println("inside ..." + hotel);
	                pst.setString(1, hotel.getCity());
	                pst.setString(2, hotel.getHotelName());
	                pst.setString(3, hotel.getAddress());
	                pst.setString(4, hotel.getDescription());
	                pst.setFloat(5, hotel.getAvgRate());
	                pst.setString(6, hotel.getPh1());
	                pst.setString(7, hotel.getPh2());
	                pst.setString(8, hotel.getRating());
	                pst.setString(9, hotel.getEmail());
	                pst.setString(10, hotel.getFax());
	                pst.setString(11, hotel.getHotelId());
	                pst.executeUpdate();
	                admLogger.log(Level.INFO,"Data Updated: "+hotel);

	                return Integer.valueOf(hotel.getHotelId());
	            }
	            else
	            {
	                throw new HotelException("Hotel doesn't exist!");
	            }


	        }
	        catch(Exception e)
	        {   
	        	admLogger.error("This is Exception:"+e.getMessage());
	            throw new HotelException("Hotel doesn't exist!");
	        }
	        finally
	        {
	            try
	            {
	                pst.close();
	                con.close();
	            }
	            catch(SQLException e)
	            {
	            	admLogger.error("This is Exception:"+e.getMessage());
	                throw new HotelException("Hotel doesn't exist!");
	            }
	        }
	    }
	@Override
	public String generateHotelId() throws HotelException 
	{
		String htlid=null;

		try
		{
			con =DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SEQUENCE);
			rs.next();
			htlid=rs.getString(1);
			admLogger.log(Level.INFO,"Hotel ID Generated: ");
		}
		catch(Exception e)
		{
			admLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				admLogger.error("This is Exception:"+e.getMessage());
				throw new HotelException(e.getMessage());
			}	
		}
		return htlid;		
	}

	@Override
	public int deleteHtl(int htlId) throws HotelException 
	{
		int dataDeleted;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.DELETE_HOTEL);
			pst.setInt(1, htlId);
			dataDeleted=pst.executeUpdate();
			admLogger.log(Level.INFO,"Data Deleted: "+htlId);
		}
		catch(Exception e)
		{
			admLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				admLogger.error("This is Exception:"+e.getMessage());
				throw new HotelException(e.getMessage());
			}
		}
		return dataDeleted;
	}

	@Override
	public int addRooms(RoomDetails room) throws HotelException 
	{
		int inserted=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.ADD_ROOM);
			pst.setString(1, room.getHotelId());
			pst.setString(2, room.getId());
			pst.setString(3, room.getNumber());
			pst.setString(4, room.getType());
			pst.setDouble(5, room.getPerNightRate());
			pst.setString(6, room.getAvailability());
			admLogger.log(Level.INFO,"Room Data Added: "+room);
			inserted = pst.executeUpdate(); //Integer.valueOf(room.getId());
		} 
		catch (Exception e) 
		{
			admLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		return inserted;
	}

	@Override
	public String updateRoom(RoomDetails room) throws HotelException
	{
		String roomupdated=null;
		try
		{
			con=DBUtil.getCon();
			PreparedStatement pst=con.prepareStatement("SELECT *FROM roomdetails WHERE "
					+ "room_id=?,hotel_id=?");
			pst.setString(1,room.getId());
			pst.setString(2,room.getHotelId());
			rs=pst.executeQuery();
			if(rs.next())
			{
				pst=con.prepareStatement(QueryMapper.UPDATE_ROOM);
				pst.setString(1,room.getNumber());
				pst.setString(2,room.getType());
				pst.setDouble(3,room.getPerNightRate());
				pst.setString(4,room.getAvailability());
				admLogger.log(Level.INFO,"Room Data Updated: "+room);
				return room.getId();
			}
			else
				throw new Exception("No such Rooms or Hotel don't exist");
		}
		catch(Exception e)
		{
			admLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				admLogger.error("This is Exception:"+e.getMessage());
				throw new HotelException(e.getMessage());
			}
		}
	}

	@Override
	public String deleteRoom(String roomid,String hid) throws HotelException 
	{
		String id = null;
		try (Connection connection = DBUtil.getCon()) {
			PreparedStatement preparedStatement = connection.prepareStatement
					("SELECT * from roomDetails where hotel_id=? and room_id=?");
			preparedStatement.setString(1, hid);
			preparedStatement.setString(2, roomid);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				PreparedStatement preparedStatement1 = connection
						.prepareStatement(QueryMapper.DELETE_ROOM);
				preparedStatement1.setString(1,roomid);
				preparedStatement1.setString(2, hid);
				preparedStatement1.executeQuery();
				admLogger.log(Level.INFO,"Room Data Deleted: ");
				return roomid;
			}
			else
			{
				throw new Exception("Hotel of "+hid+" or Room of "+roomid+" Does Not Exists..!!");
			}
		} catch (Exception e) 
		{
			admLogger.error("This is Exception:"+e.getMessage());
			throw new HotelException(e.getMessage());
		}
	}

	@Override
	public ArrayList<Hotels> getAllHotels() throws HotelException 
	{
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		Hotels h = null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.VIEW_HOTELS);
			while(rs.next())
			{
				h=new Hotels(rs.getString("hotel_id"),rs.getString("city"),
						rs.getString("hotel_name"),rs.getString("address"),
						rs.getString("description"),rs.getFloat("avg_rate_per_night"),
						rs.getString("phone_no1"),rs.getString("phone_no2"),
						rs.getString("rating"),rs.getString("email"),rs.getString("fax"));
				hotelList.add(h);
			}
		}
		catch (Exception e)
		{
			throw new HotelException("Problem in select");
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{
				throw new HotelException(e.getMessage());
			}
		}
		return hotelList;
	}

	@Override
	public ArrayList<BookingDetails> viewBookingsSpecificDate(LocalDate bookdate) throws HotelException 
	{
		ArrayList<BookingDetails>bookings=new ArrayList<BookingDetails>();
		BookingDetails bk=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.VIEW_BOOKING_DATE);
			pst.setDate(1, Date.valueOf(bookdate));
			rs=pst.executeQuery();
			while(rs.next())
			{
				BookingDetails bookingDetails = new BookingDetails(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getDate(4).toLocalDate(), rs.getDate(5).toLocalDate(),
						rs.getInt(6), rs.getInt(7), rs.getDouble(8));
				bookings.add(bookingDetails);
			}
			if (bookings.isEmpty())
				throw new Exception("No bookings has been made on : " + bookdate);
		} catch (Exception e) {
			throw new HotelException(e.getMessage());
		}
		return bookings;
	}

	@Override
	public List<User> guestOfSpecificHotel(String hotelId) throws HotelException
	{
		ArrayList<User> user = null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.VIEW_GUEST_HOTEL);
			pst.setString(1, hotelId);
			rs = pst.executeQuery();
			user = new ArrayList<>();
			while (rs.next())
			{
				pst2=con.prepareStatement(QueryMapper.SELECT_USER);
				pst2.setString(1,rs.getString(1));
				rs2=pst2.executeQuery();
				while(rs2.next())
				{
					User usr = new User(rs2.getString("user_id"),rs2.getString("password"),
								rs2.getString("user_name"),rs2.getString("mobile_no"),rs.getString("role"),
								rs2.getString("phone"),rs2.getString("address"),rs2.getString("email"));
					user.add(usr);
				}
			}
			if(user.isEmpty())
			{
				throw new Exception("Guest List is Empty for " +hotelId);
			}
		} 
		catch (Exception e) 
		{
			throw new HotelException(e.getMessage());
		}
		return user;
	}
	

@Override
    public List<BookingDetails> specificHotelBookings(String hotelId)
            throws HotelException
    {
        ArrayList<BookingDetails>bookings=null;
        try
        {
            con=DBUtil.getCon();
        //Fetch Booking Id 
            pst = con.prepareStatement(QueryMapper.BOOKING_CHECK);
            pst.setString(1, hotelId);
            rs = pst.executeQuery();
            bookings = new ArrayList<>();
            while (rs.next()) 
            {
                PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.SPECIFIC_HOTEL_BOOKING_DETAILS);
                preparedStatement.setString(1, rs.getString("booking_id"));
                 rs = preparedStatement.executeQuery();
                while (rs.next()) 
                {
                    BookingDetails bookingDetails = new BookingDetails(rs.getString(1), rs.getString(2),
                            rs.getString(3), rs.getDate(4).toLocalDate(),
                            rs.getDate(5).toLocalDate(), rs.getInt(6), rs.getInt(7),
                            rs.getDouble(8));
                    bookings.add(bookingDetails);
                }
            }
            if (bookings.isEmpty())
                throw new Exception("No bookings has been made in Hotel: " + hotelId);
        } 
        catch (Exception e) 
        {
            throw new HotelException(e.getMessage());
        }
        return bookings;
    }
}
